const express = require("express");
const app = express();
const session = require("express-session");
const db = require('./db')
const methodOverride = require('method-override');
app.set("view engine", "hbs");
app.use(methodOverride('_method'));



//START
var MySQLStore = require('express-mysql-session')(session);

var options = {
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'root',
  database: 'session_test'
};

var sessionStore = new MySQLStore(options);

app.use(session({
  key: 'session_cookie_name',
  secret: 'session_cookie_secret',
  store: sessionStore,
  resave: false,
  saveUninitialized: false
}));
//END

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const loggedInOnly = (failure = "/login") => (req, res, next) => {
  if (req.session.user) {
    next();
  } else {
    res.redirect(failure);
  }
};

app.get("/", loggedInOnly(), (req, res) => {
  db.getAllBands(req.session.user.email)
    .then((bands) => {
      res.render("index", {
        name: req.session.user.username,
        bands
      })
    })
    .catch((err) => {
      res.send(err)
    })
})




app.get('/logout', function (req, res) {
  req.session.destroy();
  res.redirect('/');
});

app.delete('/delete', (req, res) => {
  let id = req.body.bandDelete;
  db.removeBand(id)
    .then(() => {
      res.redirect('/')
    })
    .catch((err) => {
      res.send(err)
    })
})

app.post("/signup", (req, res) => {
  const { username, college, date, email, password } = req.body;
  db.createCredentials(username, college, date, email, password)
    .then(() => {
      res.redirect('/')
    })
    .catch((err) => {
      res.send(err)
    });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  db.checkCredentials(email, password).then((check) => {
    if (check.length > 0) {
      req.session.user = {
        username: check[0].username,
        email: check[0].email
      };
      res.redirect("/");
    }
    else {
      res.sendStatus(401);
    }
  });
});

app.get('/update/:id', (req, res) => {
  res.render('edit', {
    id: req.params.id
  })
})

app.post('/add', (req, res) => {
  let band = req.body.band;
  let email = req.session.user.email;

  db.addNewBand(band, email)
    .then(() => {
      res.redirect('/')
    })
    .catch((err) => {
      res.send(err)
    })
})

app.post('/update', (req, res) => {
  db.updateBand(req.body.id, req.body.bandname)
    .then(() => {
      res.redirect("/")
    })
    .catch((err) => {
      console.log(err);
      res.send(err)
    })
})
app.get('/signup',(req,res) => {
  res.render('signup')
})

app.get("/login", (req, res) => {
  if (req.session.user) {
    res.redirect("/");
  } else {
    res.render("login");
  }
});

app.listen(8080, () => console.log("running"));
